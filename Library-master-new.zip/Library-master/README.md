MB Project 1 - Library Management System
=======
Programmers:
Li Huang, Run Yan, Zhipeng Zhou, Sen Li
=======
Version History:
2014.8.15
Version 1.0

