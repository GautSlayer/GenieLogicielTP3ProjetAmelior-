package Library;

import java.io.Serializable;
import java.util.*;

public class Book implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 */
	private String bookName;
	/**
	 */
	private String author;
	/**
	 */
	private String isbn;
	/**
	 */
	private Date lastRented; //update when rent
	/**
	 */
	private Date AddedDate;
	/**
	 */
	private boolean isRented; //update when rent
	/**
	 */
	private int ownerId; //update when rent
	/**
	 */
	private Category category;
	
	Book(){
		
		isRented = false;
		ownerId = Library.LIBRARY_OWNER_ID;
		
	}
	
	//getters & setters
	/**
	 * @return
	 */
	public String getBookName() {
		return bookName;
	}
	/**
	 * @param bookName
	 */
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	/**
	 * @return
	 */
	public String getAuthor() {
		return author;
	}
	/**
	 * @param author
	 */
	public void setAuthor(String author) {
		this.author = author;
	}
	/**
	 * @return
	 */
	public String getIsbn() {
		return isbn;
	}
	/**
	 * @param isbn
	 */
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	/**
	 * @return
	 */
	public Date getLastRented() {
		return lastRented;
	}
	/**
	 * @param lastRented
	 */
	public void setLastRented(Date lastRented) {
		this.lastRented = lastRented;
	}
	/**
	 * @return
	 */
	public boolean isRented() {
		return isRented;
	}
	public void setRented(boolean isRented) {
		this.isRented = isRented;
	}
	/**
	 * @return
	 */
	public int getOwnerId() {
		return ownerId;
	}
	/**
	 * @param ownerId
	 */
	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}
	/**
	 * @return
	 */
	public Date getAddedDate() {
		return AddedDate;
	}
	/**
	 * @param addedDate
	 */
	public void setAddedDate(Date addedDate) {
		AddedDate = addedDate;
	}
	/**
	 * @return
	 */
	public Category getCategory() {
		return category;
	}
	/**
	 * @param category
	 */
	public void setCategory(Category category) {
		this.category = category;
	}
	
	
	
	
}
