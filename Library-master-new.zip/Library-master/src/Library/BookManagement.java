package Library;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

public class BookManagement {

	private final String BookListURL = "./books.dat";
	private final String DEFAULT_BOOK_IMAGE_PATH =  "./images/";
	private ArrayList<Book> bookList;
	private static BookManagement instance= null;
	
	private BookManagement()
	{
		bookList = new ArrayList<Book>();
	}
	
	public static BookManagement getInstance()
	{
		if(BookManagement.instance == null)
		{
			BookManagement.instance = new BookManagement();
		}
		return BookManagement.instance;
	}
	
	public void saveBooks() throws IOException{
		
		FileOutputStream fout = new FileOutputStream(BookListURL);
		ObjectOutputStream oos = new ObjectOutputStream(fout);
		oos.writeObject(bookList);
	}
	
	@SuppressWarnings("unchecked")
	void loadBooks() throws Exception{
		
		FileInputStream fis = new FileInputStream(BookListURL);
	    ObjectInputStream ois = new ObjectInputStream(fis);
	    bookList = (ArrayList<Book>)ois.readObject();
	    ois.close();
	}
	
	void addBook(Book b){
		b.setAddedDate(new Date());
		bookList.add(b);
		
	}//add book
	
	String getBookImgFileFullName(String isbn){
		return DEFAULT_BOOK_IMAGE_PATH+isbn + ".jpg"; //Extension .jpg
	}
	
	void updateBook(String isbn, Book b){
		Iterator<Book> bookItr = bookList.iterator();
		int index = -1;
		while(bookItr.hasNext()){
			Book tempBook = bookItr.next();
			index++;
			if(tempBook.getIsbn().equals(isbn)){
				bookList.set(index, b);
				break;
			}//end if
		}//end while
	}//update book
	
	/**
	 * Copy the book image file into the default Book Image folder.
	 * @param srcImgPath  original image file path e.g. D:/img1
	 * @param srcImgFileName original image filename,  e.g. abc.jpg
	 * @param newImgFilename new image filename, without extension,  e.g.  1234
	 * @return if success copy the file, return true; else return false;
	 * e.g. Will copy D:/img1/abc.jpg into DEFAULT_BOOK_IMG_PATH/1234.jpg. 
	 * @throws Exception
	 */
	public boolean copyBookImage(String srcImgPath, String srcImgFileName, String newImgFilename)
	{
		String srcPath = srcImgPath + srcImgFileName;
		FileInputStream fi;
		try {
			fi = new FileInputStream(srcPath);
		} catch (FileNotFoundException e) {
			//e.printStackTrace();
			return false;
		}
		BufferedInputStream in = new BufferedInputStream(fi);
		newImgFilename = srcImgFileName.replaceAll(srcImgFileName,
				newImgFilename) + ".jpg";
		File destDir = new File(DEFAULT_BOOK_IMAGE_PATH);
		if (!destDir.exists()) {
			destDir.mkdir();
		}
		String destPath = destDir.toString() + "\\" + newImgFilename;
		FileOutputStream fo;
		try {
			fo = new FileOutputStream(destPath);

			BufferedOutputStream out = new BufferedOutputStream(fo);
			byte[] buf = new byte[1024];
			int len = in.read(buf);
			while (len != -1) {
				out.write(buf, 0, len);
				len = in.read(buf);
			}
			out.close();
			fo.close();
			in.close();
			fi.close();
			return true;
			
		} catch (Exception e) {
			return false;
		}
	}
	/**
	 * add a book into library, and also copy its image file into the default book image folder.
	 * add by Li Huang 2014.8.14
	 * @param b Book
	 * @param srcBookImgPath original book image file path e.g. D:/img1
	 * @param srcBookImgFileName original image filename,  e.g. abc.jpg
	 */
	void addBook(Book b, String srcBookImgPath, String srcBookImgFileName){
		b.setAddedDate(new Date());
		copyBookImage(srcBookImgPath,srcBookImgFileName,b.getIsbn());
		bookList.add(b);
	}//add book
	
	boolean deleteBook(String isbn){
		Iterator<Book> bookItr = bookList.iterator();
		int index = -1;
		while(bookItr.hasNext()){
			Book tempBook = bookItr.next();
			index++;
			if(tempBook.getIsbn().equals(isbn)){
				//***********************************************
				//modified by Sen Li after demo
				//rented book can not be deleted.
				if(tempBook.isRented()==true){
					return false;
				}
				else{
					bookList.remove(index);
					return true;
				}
				//***********************************************
				
			}//end if
			
		}//end while
		return false;
	}//delete book
		
	public ArrayList<Book> getBookList(){
		
		return bookList;
	}//show all books
}
