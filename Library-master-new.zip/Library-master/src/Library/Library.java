package Library;

import java.io.*;
import java.text.*;
import java.util.*;

import javax.swing.JOptionPane;

/**
 * Library class, manage books and users
 * @author Sen Li
 * add 2014.8.11
 * edit by Run Yan 2014.8.14: fix bug at fine()
 * make all the member variables private
 * add copyBookImage() and addBook(book,srcBookImgPath,srcBookImgFilename) methods
 */
public class Library {
	
	public static final int LIBRARY_OWNER_ID = 0; // ownerId of the library is 0. i.e. not rented.  
	/**
	 */
	private final long OverdueTimeLimit = 60*1000; // in millisecond
	/**
	 */
	private final long NewbookTimeLimit = 60*1000; // in millisecond
	/**
	 */
	private final int FINE_PER_SECOND = 1;
	private static Library intance = null;
	private Library(){ //constructor
	}
	
	public static Library getInstance()
	{
		if(Library.intance == null)
		{
			Library.intance = new Library();
		}
		return Library.intance;
	}
	
	ArrayList<Book> showBookList_rented(){
		
		Iterator<Book> bookItr = BookManagement.getInstance().getBookList().iterator();
		ArrayList<Book> tempBookList = new ArrayList<Book>();
		while(bookItr.hasNext()){
			Book tempBook = bookItr.next();
			if(tempBook.isRented() == true){
				tempBookList.add(tempBook);
			}//end if
		}//end while
		
		return tempBookList;
		
	}//
	
	ArrayList<Book> showBookList_All(){
		
		return BookManagement.getInstance().getBookList();
		
	}//
	
	ArrayList<Book> showBookList_remainder(){
		
		Iterator<Book> bookItr = BookManagement.getInstance().getBookList().iterator();
		ArrayList<Book> tempBookList = new ArrayList<Book>();
		while(bookItr.hasNext()){
			Book tempBook = bookItr.next();
			if(tempBook.isRented() != true){
				tempBookList.add(tempBook);
			}//end if
		}//end while
		
		return tempBookList;
	}
	
	ArrayList<Book> showBookList_BorrowedByCustomer(int customerId){
	
		Iterator<Book> bookItr = BookManagement.getInstance().getBookList().iterator();
		ArrayList<Book> tempBookList = new ArrayList<Book>();
		while(bookItr.hasNext()){
			Book tempBook = bookItr.next();
			if(tempBook.getOwnerId()==customerId){
				tempBookList.add(tempBook);
				
			}//end if
		}//end while
		return tempBookList;	
	}
	
	
	ArrayList<Book> showBookList_overdue(){
		
		Iterator<Book> bookItr = BookManagement.getInstance().getBookList().iterator();
		ArrayList<Book> tempBookList = new ArrayList<Book>();
		while(bookItr.hasNext()){
			Book tempBook = bookItr.next();
			if(tempBook.isRented()==true){
				if(tempBook.getLastRented() == null)
					continue;
				if(new Date().getTime() - tempBook.getLastRented().getTime() >=  OverdueTimeLimit)
					tempBookList.add(tempBook);
					
				
				
			}//end if
		}//end while
		
		return tempBookList;
	}
	
	
	boolean rentBook(int customerId, String isbn){
		
		Iterator<Book> bookItr = BookManagement.getInstance().getBookList().iterator();
		while(bookItr.hasNext()){
			Book tempBook = bookItr.next();
			if(tempBook.getIsbn().equals(isbn) && tempBook.isRented()==false){
				tempBook.setLastRented(new Date());
				tempBook.setRented(true);
				tempBook.setOwnerId(customerId);
				return true;
			}//end if
		}//end while
		return false;
	}
	
	void returnBook(String isbn){
		

		Iterator<Book> bookItr = BookManagement.getInstance().getBookList().iterator();
		while(bookItr.hasNext()){
			Book tempBook = bookItr.next();
			if(tempBook.getIsbn().equals(isbn)){
				tempBook.setRented(false);
				tempBook.setOwnerId(LIBRARY_OWNER_ID);
				
			}//end if
		}//end while

	}
	
	ArrayList<Book> showBookList_preferedCategory(Category[] ctgList){
		
		ArrayList<Book> tempBookList = new ArrayList<Book>();
		Category currentCtg = null;
		for(int i =0;i<ctgList.length;i++){//for each category
			currentCtg = ctgList[i];
			Iterator<Book> bookItr = BookManagement.getInstance().getBookList().iterator();
			while(bookItr.hasNext()){
				Book tempBook = bookItr.next();
				if(tempBook.getCategory()==currentCtg){
					tempBookList.add(tempBook);
					
				}//end if
			}//end while
			
		}//end for
		return tempBookList;
		
	}
	
	ArrayList<Book> showBookList_new(Category[] ctgList){
		
		Date currentDate = new Date(); 
		ArrayList<Book> tempBookList = new ArrayList<Book>();
		Category currentCtg = null;
		for(int i =0;i<ctgList.length;i++){//for each category
			currentCtg = ctgList[i];
			Iterator<Book> bookItr = BookManagement.getInstance().getBookList().iterator();
			while(bookItr.hasNext()){
				Book tempBook = bookItr.next();
				if(tempBook.getCategory()==currentCtg){
					
					if(currentDate.getTime() - tempBook.getAddedDate().getTime() < NewbookTimeLimit)
					tempBookList.add(tempBook);
					
				}//end if
			}//end while
			
		}//end for
		return tempBookList;
		
	}
	
	public double fine(String isbn, Date returnDate){
		
		Iterator<Book> bookItr = BookManagement.getInstance().getBookList().iterator();
		while(bookItr.hasNext()){
			Book tempBook = bookItr.next();
			if(tempBook.getIsbn().equals(isbn)){
				//this book found
				int overdue_time_seconds = (int)(returnDate.getTime() - tempBook.getLastRented().getTime() - OverdueTimeLimit )/1000;
				if (overdue_time_seconds<0)
					overdue_time_seconds=0;
				double fine_amount = overdue_time_seconds*FINE_PER_SECOND;
				return fine_amount;
			}//end if
		}//end while
		
		return 0.0;
	}
	
	public Book getBookByISBN(String isbn){
		
		Iterator<Book> bookItr = BookManagement.getInstance().getBookList().iterator();
		while(bookItr.hasNext()){
			Book tempBook = bookItr.next();
			if(tempBook.getIsbn().equals(isbn)){
				return tempBook;
			}//end if
			
		}//end while
		
		return new Book();
	}	
}
