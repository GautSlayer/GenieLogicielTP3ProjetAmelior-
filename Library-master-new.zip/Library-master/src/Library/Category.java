package Library;

public enum Category { 
	CHILDREN, COOKING, HISTORY, TRAVEL
}
